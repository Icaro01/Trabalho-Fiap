function toggleSidebar() {
  var sidebar = document.getElementById('sidebar');

  sidebar.classList.toggle('open');
}